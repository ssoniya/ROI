import os,shutil
import cv2

import numpy as np


from thaisegMain import initialize
from GetHTML import genHTMLFile

from roiSelection import *
from DetectText import *


#modelName="Models/Thai-1-00300000.pyrnn.gz"

outPut='data/outputs'
mask_path = "data/inputs/"

def getImageSegments(imagePath, segPath):
	image = cv2.imread(imagePath)

	if getImageSource(image) is "camera" :
		res,temp = getROI(image)
		if res == 0:
			image = temp

	resized = cv2.resize(image, (400,252), interpolation=cv2.INTER_AREA)
	
	mask = cv2.imread(mask_path + "mask2.jpg",cv2.IMREAD_GRAYSCALE)
	imgBinR = cv2.threshold(mask, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

	mask_id = cv2.imread(mask_path + "mask4.png",cv2.IMREAD_GRAYSCALE)
	imgBinR_id = cv2.threshold(mask_id, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

	masked_data = cv2.bitwise_and(resized, resized, mask=imgBinR)
	masked_data = cv2.bitwise_and(masked_data, masked_data, mask=imgBinR_id)

	cv2.imwrite(segPath + "roi.jpg", resized)
	cv2.imwrite(segPath + "roi_masked.jpg", masked_data)

	getTextLocal(segPath + "roi_masked.jpg")

	masked_data = cv2.bitwise_and(resized, resized, mask=imgBinR)

	f=open(segPath+'mainBlobs.txt','r')
	num=1
	for lines in f:
		splitL=lines.split()
		x=int(splitL[0])
		y=int(splitL[1])
		w=int(splitL[2])
		h=int(splitL[3])
		img1 = masked_data[y:y+h,x:x+w,:]

		r, g, b = cv2.split(img1)

		clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
		clr = clahe.apply(r)
		clg = clahe.apply(g)
		clb = clahe.apply(b)
		limg1 = cv2.merge((clr, clg, clb))

		tempImg1 = cv2.cvtColor(limg1, cv2.COLOR_BGR2GRAY)
		cv2.imwrite(segPath + str(num) + "_clahe.jpg", tempImg1)
		
		cm = './imgProcessing/binarize/src/binarizewolfjolion w ' + segPath + str(num) + '_clahe.jpg ' + segPath + str(num) + '.png'
		os.system(cm)


		#cv2.imwrite(segPath + str(num) + '.png', img1)
		num=num+1

	
	sample= cv2.imread(segPath + str(num-1) + '.png',cv2.IMREAD_GRAYSCALE)
	bin1  = cv2.threshold(sample,128,255,cv2.THRESH_BINARY)

	sumRows = []
	ht,wt=sample.shape[:2]
	j=0
	while j<ht:
		rw=wt-sum(sample[j,:])/255
		sumRows.append(rw)
		j=j+1

	histLen = len(sumRows)
	index_min = np.argmin(sumRows[3:(histLen-4)])
	#print sumRows,index_min
	img1 = sample[0:index_min+3,:]
	img2 = sample[index_min+3:histLen,:]
	cv2.imwrite(segPath + str(num-1) + '.png', img1)
	cv2.imwrite(segPath + str(num) + '.png', img2)


def mainOCR(imgPath):

	''''''''''''''''''''' Line Segmentation '''''''''''''''
	if os.path.isdir(outPut):
		shutil.rmtree(outPut)


	pathSplit=imgPath.split('/')
	sz=len(pathSplit)
	if sz>=1:
		fname=os.path.splitext(pathSplit[sz-1])[0]
	else:
		print('File name in path does not exist')

	fileLoc=outPut+'/'+fname+'/'
	os.makedirs(fileLoc)

	getImageSegments(imgPath, fileLoc)


	#initialize(imgPath,outPut)

	''''''''''''''''''''' OCR Prediction '''''''''''''''
	#commandStr="ocropus-rpred -n -m "+modelName+ " "+nF+"/*/*.png"
	#os.system(commandStr)
	#print commandStr
	''''''''''''''''''''' Creating HTML '''''''''''''''
	#out=genHTMLFile(nF,'b_'+imageName.lower().replace(".jpg",""))
	''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
	#return(out)


#if __name__ == '__main__':

#	if os.path.isdir(outPut):
#		shutil.rmtree(outPut)

#	imgPath = "../data/inputs/training/sample"
	#imgPath = "../data/inputs/camera/"

#	for i in range(1, 34):
		
#		if i == 21 or i==24 or i==30:
#			continue

#		fpath = imgPath + str(i) + ".jpg"
#		outpath = "../data/outputs/" + str(i)
#		os.makedirs(outpath)
#		outpath = outpath + "/"
#		getImageSegments(fpath, outpath)
