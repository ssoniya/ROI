import webbrowser
import codecs
#import pdfkit
#nm='myHtml.html'
#f = open(nm,'w')

start = """
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
"""
end="""
</body>
</html>"""


nm='outHTML.html'

def genHTMLFile(folder,imageName):
	fpath=folder+"/"+imageName
	print fpath
	lNum=1
	bodyText=''
	try:
		fw=open(fpath+'/'+nm,'w')
		f=open(fpath+'/file.txt','r')
		for lines in f:
			
			if lNum==1:
				lNum=lNum+1
				continue		
			splitL=lines.split()
			num=int(splitL[0])
			x=int(splitL[1])/2
			y=int(splitL[2])/2
			w=int(splitL[3])
			h=int(splitL[4])
			#wh=int(splitL[5])
			#z=int(splitL[6])		
			try:
				#print num,fpath
#				print lines,num
				fop=open(fpath+'/'+str(num)+'.txt','r')
				#fop=codecs.open(fpath+'/'+str(num)+'.txt',encoding('utf-8'))
				oline=fop.read()
				oline=oline.strip()
				if  oline[0]=="~":
					oline=oline[1:]			
				fop.close()
				print oline,num
				#online = online.encode('utf-8')
				strg='<DIV style="position: absolute; width:100%;top:'+str(y)+'px;left:'+str(x)+'px">'+oline+'</div>'
			#	print strg
				bodyText=bodyText+'\n'+strg
			#	break
			except:
				continue
			
		msg=start+bodyText+end
		fw.write(msg)
		fw.close()
		f.close()
		#filename = 'file:///home/avinash/Desktop/HCL/Python Codes/Android POC/Training & Testing/Testing Thai/'+fpath+'/'+nm
		#webbrowser.open_new_tab(filename)
		return(fpath+"/"+nm)
	except:
		print 'Error in HTML creation'
		return('-1')


#fp='/home/ss/Desktop/mc/wert/set 19/howard leonard 3'
#genHTMLFile(fp)

