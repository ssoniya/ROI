import numpy as np
import cv2
import os
import matplotlib.pyplot as plt

def initialize(fpath,nF):
	newFolder=nF
	pathSplit=fpath.split('/')
	#print pathSplit
	sz=len(pathSplit)
	if sz>=1:
		fname=os.path.splitext(pathSplit[sz-1])[0]
	else:
		print('File name in path does not exist')
	#print fname
	fileLoc=newFolder+'/'+fname+'/'
	os.makedirs(fileLoc)
	approach(fpath,fileLoc)


def approach(fpath, folder):
    image = cv2.imread(fpath)
    imagepD = cv2.pyrUp(image)

    R = image[:, :, 0]
    G = image[:, :, 1]
    B = image[:, :, 2]
    R = cv2.GaussianBlur(R, (5, 5), 5.0)
    B = cv2.GaussianBlur(B, (5, 5), 5.0)
    G = cv2.GaussianBlur(G, (5, 5), 5.0)
    R = cv2.medianBlur(R, 5)
    G = cv2.medianBlur(G, 5)
    B = cv2.medianBlur(B, 5)
    RG = np.minimum(R, G)
    RGB = np.minimum(RG, B)

    cv2.imwrite(folder + 'i_img.jpg', cv2.pyrDown(RGB))

    fn=folder + 'i_img.jpg'         #after blurring
    img = cv2.imread(fn,0)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    cl1 = clahe.apply(img)
    fn = folder + 'c_img.jpg'       #after clahe
    cv2.imwrite(fn,cl1)

    Bfn= folder + 'b_img.jpg'

    cm='./imgProcessing/binarize/src/binarizewolfjolion w '+fn+' '+Bfn
    os.system(cm)

    image = cv2.imread(Bfn, 0)

    imgpD = image
    img1 = imgpD
    cv2.imwrite(folder + 'img_bw.jpg', image)
    kernel = np.ones((3, 9), np.uint8)
    kernel1 = np.ones((7, 19), np.uint8)
    #	morph_kernel = getStructuringElement(cv2.MORPH_ELLIPSE, (5, 3)) # was (3,3)
    #	grad = cv2.morphologyEx(imgpD, cv2.MORPH_GRADIENT, morph_kernel)
    imgpD = cv2.GaussianBlur(imgpD, (3, 9), 1.5)
    imgpD = cv2.GaussianBlur(imgpD, (3, 9), 1.5)
    #	imgpD= cv2.GaussianBlur(imgpD, (3,5), -.5)
    imdV = cv2.dilate(cv2.bitwise_not(imgpD), kernel1, iterations=1)
    # imdV=cv2.dilate(imdV,kernel,iterations=1)
    # blur= cv2.GaussianBlur(imdV, (5,5), 10.0)
    # plt.subplot(2,1,1)
    # plt.imshow(imgpD,'gray')#;plt.show()
    # plt.subplot(2,1,2)
    plt.imshow(imdV, 'gray');
    plt.show()
    idx = 1
    cnts = cv2.findContours(imdV, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    # cv2.drawContours(img1, cnts, -1, (0,0,255), 2) #draw all contours
    # plt.imshow(img1,'gray');plt.show()
    fwrite = open(folder + '/file.txt', 'w')
    fwrite.write('Num\tx\ty\tw\th\n')
    for c in reversed(cnts):
        [x, y, w, h] = cv2.boundingRect(c)
        if h <= 20 or w <= 20:
            continue

        tempImg = imgpD[y:y + h, x:x + w]
        pixs = w * h
        zero = pixs - cv2.countNonZero(tempImg);
        if zero < h:
            continue
            #		tempImg = cv2.cvtColor(tempImg, cv2.COLOR_BGR2GRAY)
            #		tempImg = cv2.threshold(tempImg, 200, 255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
        cv2.imwrite(folder + str(idx) + ".png", tempImg)
        fwrite.write(str(idx) + '\t' + str(x) + '\t' + str(y) + '\t' + str(w) + '\t' + str(h) + '\n')
        cv2.rectangle(img1, (x, y + h), (x + w, y), (0, 255, 0), 1)
        cv2.rectangle(imgpD, (x, y + h), (x + w, y), (255, 255, 255), -1)
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(imgpD, str(idx), (x - 1, y - 2), font, 1, (255, 0, 0))
        idx = idx + 1
    # plt.imshow(cv2.pyrDown(imagepD),'gray'),plt.show()
    cv2.imwrite(folder + 'img_fin.jpg', img1)
    fwrite.close()

# cv2.imwrite(folder+'img_fin.jpg',cv2.pyrDown(img1))
