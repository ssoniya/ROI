import cv2
import traceback

def removeDupBlob(fpath):
	lNum=1
	lTh=10#15
	myList=[]
	count=0
	try:
		fw=open(fpath+'/mainBlobs.txt','w')
		f=open(fpath+'/lineCords.txt','r')
		for lines in f:
			if lNum==1:
				lNum=lNum+1
				continue	
			splitL=lines.split()
			x=int(splitL[0])
			y=int(splitL[1])
			w=int(splitL[2])
			h=int(splitL[3])		
			myList.append([x,y,w,h])
		f.close()
		sList=sorted(myList, key=lambda x: (x[1], x[0]))
		fnum=0;setB=[]
	
		for [x,y,w,h] in sList:
			#print (count+1)
			if fnum==0:	
				fx=x;fy=y;fnum=1
				setB.append([x,y,w,h])
			else:
				if y>=fy and y<=fy+lTh:
#				if y>=fy-lTh and y<=fy+lTh:
					setB.append([x,y,w,h])
#					fy=y
			
				else:
					sortB=sorted(setB, key=lambda x: (x[0]))
					newX,newY,newW,newH=sortB[0];newX2=newX+newW;
					#print sortB[0],'first elem'
					for [xB,yB,wB,hB] in sortB[1:]:
						
						if xB<=newX2:
							newY=min(newY,yB)
							newX2=max(xB+wB,newX2)
							newH=max(newH,hB);newW=newX2-newX
							#print 'if',[xB,yB,wB,hB],[newX,newY,newW,newH]
						else:
							#print 'in else',[xB,yB,wB,hB]
							fw.write(str(newX)+'\t'+str(newY)+'\t'+str(newW)+'\t'+str(newH)+'\n')
							[newX,newY,newW,newH]=[xB,yB,wB,hB];newX2=newX+newW;
					fw.write(str(newX)+'\t'+str(newY)+'\t'+str(newW)+'\t'+str(newH)+'\n')	
					count=count+1;#print count
					setB=[];setB.append([x,y,w,h])
					fx=x;fy=y
		newX,newY,newW,newH=sortB[0];wid=newX+newW;#print sortB[0],'last'
		for [xB,yB,wB,hB] in sortB[1:]:
#		print [xB,yB,wB,hB]
			if xB<=wid:
				newY=min(newY,yB)
				newX2=max(xB+wB,wid)
				newH=max(newH,hB);newW=newX2-newX
			else:
				fw.write(str(newX)+'\t'+str(newY)+'\t'+str(newW)+'\t'+str(newH)+'\n')
				[newX,newY,newW,newH]=[xB,yB,wB,hB];wid=newX+newW;
		fw.write(str(newX)+'\t'+str(newY)+'\t'+str(newW)+'\t'+str(newH)+'\n')	
		fw.write(str(69)+'\t'+str(33)+'\t'+str(102)+'\t'+str(20)+'\n')
		fw.close()
	except:
		print 'Error in reconstruct',traceback.print_exc()

def plotBlobs(fpath):
	img = cv2.imread(fpath + '/roi.jpg')
	f=open(fpath+'/mainBlobs.txt','r')
	for lines in f:
		splitL=lines.split()
		x=int(splitL[0])
		y=int(splitL[1])
		w=int(splitL[2])
		h=int(splitL[3])
		cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
	cv2.imwrite(fpath + '/roi_masked_mainBlobs.jpg',img)
