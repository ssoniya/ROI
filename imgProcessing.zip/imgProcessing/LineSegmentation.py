import cv2
import numpy as np
import matplotlib.pyplot as plt
import os,shutil

def approach(fpath,folder):
	#print fpath,'/t',folder

	image = cv2.imread(fpath)
	imagepD=cv2.pyrUp(image)

	R=image[:,:,0]
	G=image[:,:,1]
	B=image[:,:,2]
	R= cv2.GaussianBlur(R, (5,5), 5.0)
	B= cv2.GaussianBlur(B, (5,5), 5.0)
	G= cv2.GaussianBlur(G, (5,5), 5.0)
	R= cv2.medianBlur(R, 5)
	G= cv2.medianBlur(G, 5)
	B= cv2.medianBlur(B, 5)
	RG=np.minimum(R,G)
	RGB=np.minimum(RG,B)

	#cv2.imwrite('img_fin.jpg',cv2.pyrDown(RGB))
	#binCmdStr = "./binarizewolfjolion-master/src/binarizewolfjolion w " + fpath + " " +folder+'img_bw.jpg'
	imgBinR = cv2.threshold(RGB, 200, 255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]


	imgpD = cv2.pyrUp(imgBinR)
	img1=imgpD
#	edges = cv2.Canny(RGB,20,150,apertureSize = 3)
	cv2.imwrite(folder+'img_bw.jpg',imgBinR)
	kernel = np.ones((7,19),np.uint8)
#	morph_kernel = getStructuringElement(cv2.MORPH_ELLIPSE, (5, 3)) # was (3,3)
#	grad = cv2.morphologyEx(imgpD, cv2.MORPH_GRADIENT, morph_kernel)
	imdV=cv2.dilate(cv2.bitwise_not(imgpD),kernel,iterations=1)
	#blur= cv2.GaussianBlur(imdV, (5,5), 10.0)
	plt.imshow(imdV,'gray');plt.show()
	idx=1
	cnts = cv2.findContours(imdV, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2]
#	cv2.drawContours(imagepD, cnts, -1, (0,0,255), 2) #draw all contours
	fwrite=open(folder+'/file.txt','w')
	fwrite.write('Num\tx\ty\tw\th\n')
	for c in reversed(cnts):
		[x, y, w, h] = cv2.boundingRect(c)
		#if h>30:
		#   continue
		#cv2.rectangle(imagepD, (x, y+h), (x+w, y), (0,255,0),1)        
		tempImg=imagepD[y:y+h, x:x+w]
		tempImg = cv2.cvtColor(tempImg, cv2.COLOR_BGR2GRAY)
		tempImg = cv2.threshold(tempImg, 220, 255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
		cv2.imwrite(folder+str(idx) + ".png", tempImg)
		fwrite.write(str(idx)+'\t'+str(x)+'\t'+str(y)+'\t'+str(w)+'\t'+str(h)+'\n')

	       	font = cv2.FONT_HERSHEY_SIMPLEX
 #       	cv2.putText(imagepD,str(idx), (x-1,y-2), font, 1, (255,0,0))
		idx=idx+1
	#plt.imshow(cv2.pyrDown(imagepD),'gray'),plt.show()
	cv2.imwrite(folder+'img_fin.jpg',cv2.pyrDown(imagepD))
	fwrite.close()
##################################################################################################################


def initialize(fpath,nF):
	newFolder=nF
	pathSplit=fpath.split('/')
	#print pathSplit
	sz=len(pathSplit)
	if sz>=1:
		fname=os.path.splitext(pathSplit[sz-1])[0]
	else:
		print('File name in path does not exist')
	#print fname
	fileLoc=newFolder+'/'+fname+'/'
	os.makedirs(fileLoc)
	approach(fpath,fileLoc)


